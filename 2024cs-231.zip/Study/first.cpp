#include <iostream>
using namespace std;
main() {
cout<<"my name is Affan";
}

