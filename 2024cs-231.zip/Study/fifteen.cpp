#include <iostream>
using namespace std;
main()
{
	cout<<"-------------------------------------   " << endl;
	cout<<"	        o   ^____^		       " << endl;
	cout<<"          o   (oo) \\___________        " << endl;
	cout<<"             (____)\\           )\\//\\ " << endl;
	cout<<"                    ||----w    ||       " << endl;
	cout<<"                    ||         ||       " << endl;




}