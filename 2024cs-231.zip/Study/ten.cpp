#include <iostream>
using namespace std;
main()
{
system (" color 13");
cout<<"         .::---::..      "<<endl;
cout<<"      .-------------.    "<<endl;
cout<<"    .-----------------   "<<endl;
cout<<"    ----------------:.   "<<endl;
cout<<"   :------------::.      "<<endl;
cout<<"   ------------:.        "<<endl;
cout<<"   :--------------:..    "<<endl;
cout<<"    :-----------------:. "<<endl;
cout<<"     .----------------:  "<<endl;
cout<<"       .:----------:.    "<<endl;

}
