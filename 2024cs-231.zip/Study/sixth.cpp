#include<iostream>
using namespace std;
main()
{
	cout<<"               square            "<<endl;

	cout<<"             ##########          "<<endl;
	cout<<"             #        #          "<<endl;
	cout<<"             #        #          "<<endl;
	cout<<"             #        #          "<<endl;
	cout<<"             ##########          "<<endl;


	cout<<"              Triangle           "<<endl;

	cout<<"			*               "<<endl;
	cout<<"		      *   *             "<<endl;
	cout<<"		     *     *            "<<endl;
	cout<<"		    *       *           "<<endl;
	cout<<"		   *  *  * * *          "<<endl;
	


	cout<<"		       circle           "<<endl;

	cout<<"		        :::::           "<<endl;
	cout<<"             :::      :::        "<<endl;
	cout<<"            ::           ::      "<<endl;
	cout<<"            :             :      "<<endl;
	cout<<"            :             :      "<<endl;
	cout<<"             ::         ::       "<<endl;
	cout<<"               :::    :::        "<<endl;
	cout<<"	       	         ::::           "<<endl;



	cout<<"	             Parallelogram      "<<endl;

	cout<<"	             $$$$$$$$$$$        "<<endl;
	cout<<"	            $         $         "<<endl;
	cout<<"	           $         $          "<<endl;
	cout<<"	          $$$$$$$$$$$           "<<endl;



	cout<<"                Hexagon          "<<endl;

	cout<<"		       *******          "<<endl;
	cout<<"		      *       *         "<<endl;
	cout<<"		     *         *        "<<endl;
	cout<<"		      *       *         "<<endl;
	cout<<"		       *******          "<<endl;


}