#include <iostream>
using namespace std;
main ()
{
                   cout<<" +--^-------------,-----------,----------,------------^__,    "<<endl;
                   cout<<" ||  ||||||||||     '-------'             ||              0   "<<endl;
                   cout<<"  ,+--------------------------------------^----------------|| "<<endl;
                   cout<<"   ,--------------,----------,----------------------------'   "<<endl;
                   cout<<"     /   XXXXXXXX  /'||       /'                              "<<endl;
                   cout<<"    /   XXXXXXXX  /  ||      /'                               "<<endl;
                   cout<<"   /   XXXXXXXX  /'---------'                                 "<<endl;
                   cout<<"  /   XXXXXXXX  /                                             "<<endl;
                   cout<<" /   XXXXXXXX  /                                              "<<endl;
                   cout<<"(--------------(                                              "<<endl;
                   cout<<"  '----------'                                                "<<endl;
}



















